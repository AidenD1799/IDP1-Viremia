﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Quiz : MonoBehaviour
{
    public GameObject ui;
    public bool quizOpen;

    public GameObject question1;
    public GameObject result1Correct;
    public GameObject result1Wrong;

    
    public void ToggleQuizMenu()
    {
        ui.SetActive(!ui.activeSelf);

        if (ui.activeSelf)
        {
            Time.timeScale = 0f;
        }
        else
        {
            Time.timeScale = 1f;
        }
    }

    public void RightAnswer()
    {
        PlayerStats.money += 100;
        question1.SetActive(false);
        result1Correct.SetActive(true);
    }

    public void WrongAnswer()
    {
        question1.SetActive(false);
        result1Wrong.SetActive(true);
    }
}
