﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildManager : MonoBehaviour
{
    public static BuildManager instance;
    public NodeUI nodeUI;


    void Awake()
    {
        if (instance != null)
        {
            Debug.LogError("More than one buildManager in scene");
        }
        instance = this;
    }

   

    public bool CanBuild { get { return turretToBuild != null; } }
    public bool HasMoney { get { return PlayerStats.money >= turretToBuild.cost; } }

   
     public void SelectTurretToBuild(TurretBlueprint turret)
    {
        turretToBuild = turret;
        nodeSelected = null;

        nodeUI.Hide();
    }

    private TurretBlueprint turretToBuild;
    private Node nodeSelected;

    public void SelectNode(Node node)
    {
        if(nodeSelected == node)
        {
            DeselectNode();
            return;
        }
        nodeSelected = node;
        turretToBuild = null;

        nodeUI.SetTarget(node);
    }

    public void DeselectNode()
    {
        nodeSelected = null;
        nodeUI.Hide();
    }

  public TurretBlueprint GetTurretToBuild()
    {
        return turretToBuild;
    }
}
